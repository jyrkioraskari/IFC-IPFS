package org.lbd;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.lbd.ifc.RootEntity;
import org.lbd.rdf.CanonizedPattern;
import org.lbd.statistics.Statistics;
import org.rdfcontext.signing.RDFC14Ner;

import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResourceFactory;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.vocabulary.RDF;

import io.ipfs.api.IPFS;
import io.ipfs.api.MerkleNode;
import io.ipfs.api.NamedStreamable;

/*
* The GNU Affero General Public License
* 
* Copyright (c) 2018 Jyrki Oraskari (Jyrki.Oraskari@gmail.f)
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU Affero General Public License as
* published by the Free Software Foundation, either version 3 of the
* License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Affero General Public License for more details.
* 
* You should have received a copy of the GNU Affero General Public License
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

public class IfcIPFS {
	static List<Statistics> statistics = new ArrayList<>();
	static Statistics current_process;;

	private final Model jena_guid_directory_model = ModelFactory.createDefaultModel();
	private final Property jena_property_merkle_node;
	private final IPFS ipfs;
	private final String baseURI = "http://ipfs/bim/";
	static long start_time = System.currentTimeMillis();
	private final CanonizedPattern canonized_pattern=new CanonizedPattern();


	private IfcIPFS(String ifcrdf_file) throws InterruptedException, IOException {
		current_process = new Statistics(ifcrdf_file);
		statistics.add(current_process);
		current_process.setProcess_start_time(System.currentTimeMillis());
		this.jena_property_merkle_node = jena_guid_directory_model.createProperty("http://ipfs/MerkleNode_Hash");

		ipfs = new IPFS("/ip4/127.0.0.1/tcp/5001");

		processIfc(ifcrdf_file);
		current_process.setProcess_stop_time(System.currentTimeMillis());
	}

	private void processIfc(String ifc_file) {
		long start = System.currentTimeMillis();
		Splitted_NoGeometryIfcOWLMeasure ifcrdf = new Splitted_NoGeometryIfcOWLMeasure(ifc_file);
		IfcIPFS.current_process.setIfc_convert(System.currentTimeMillis() - start);

		
		
		start = System.currentTimeMillis();
		ifcrdf.split();
		IfcIPFS.current_process.setIfc_split(System.currentTimeMillis() - start);
		IfcIPFS.current_process.setFiltered_triples(ifcrdf.getTotal_count());
		IfcIPFS.current_process.setIfc_root_entities(ifcrdf.getRoots().size());
		IfcIPFS.current_process.setIfcowl_triples(ifcrdf.getModel().size());

		start = System.currentTimeMillis();
		publishEntityNodes2IPFS(ifcrdf.getEntitys(), ifcrdf.getURI2GUID_map());
		IfcIPFS.current_process.setPublish_merkle_nodes(System.currentTimeMillis() - start);

		start = System.currentTimeMillis();
		MerkleNode project_table = publishDirectoryNode2IPFS("IFC Project", jena_guid_directory_model);
		//System.out.println("pt:"+project_table.hash.toBase58());
		IfcIPFS.current_process.setPublish_directory_node(System.currentTimeMillis() - start);
		/*start = System.currentTimeMillis();
		String ipns_name=null;
		try {
			Map pub = ipfs.name.publish(project_table.hash);
			ipns_name=(String)pub.get("Name");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		//System.out.println("IPNS publish time:"+(System.currentTimeMillis() - start));
		IfcIPFS.current_process.setIpns_name_publish(System.currentTimeMillis() - start);
*/
		/*
		if(ipns_name==null)
			return;
		start = System.currentTimeMillis();
		try {
			Multihash filePointer = Multihash.fromBase58(ipns_name);
			String resolved = ipfs.name.resolve(filePointer);
			System.out.println("Resolved: "+resolved);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		System.out.println("IPNS resolve time:"+(System.currentTimeMillis() - start));
		*/

	}

	private Map<String, Resource> resources_map = new HashMap<>();

	private void publishEntityNodes2IPFS(List<RootEntity> root_entitys, Map<String, String> uri2guid) {

		for (RootEntity g1 : root_entitys) {
			Resource guid_subject = null;
			for (Statement triple : g1.getTriples()) {

				String s_uri = triple.getSubject().getURI();
				Resource subject = null;
				String sg = uri2guid.get(s_uri); // The map sets the coding
				if (sg != null) {
					String sn = s_uri.substring(0, (s_uri.lastIndexOf("/") + 1)) + sg;
					subject = ResourceFactory.createResource(sn);
					guid_subject = subject;
					resources_map.put(s_uri, subject);
				}
			}
		}

		for (RootEntity g : root_entitys) {
			Resource guid_subject = null;
			Model entity_model = ModelFactory.createDefaultModel();
			boolean random_added = false;
			for (Statement triple : g.getTriples()) {

				String s_uri = triple.getSubject().getURI();
				Resource subject = null;
				String sg = uri2guid.get(s_uri); // The map sets the coding
				if (sg != null) {
					String sn = s_uri.substring(0, (s_uri.lastIndexOf("/") + 1)) + sg;
					subject = entity_model.createResource(sn);
					guid_subject = subject;
					resources_map.put(s_uri, subject);
					
				}

				if (subject == null) {
					subject = resources_map.get(s_uri);
					if (subject == null) {
						subject = entity_model.createResource();
						resources_map.put(s_uri, subject);
					}
				}

				Property property = entity_model
						.getProperty(triple.getPredicate().getURI());
				RDFNode object = triple.getObject();
				if (object.isResource()) {
					Resource or = resources_map.get(object.asResource().getURI());
					if (or == null) {
						if (property.toString().equals(
								"http://www.buildingsmart-tech.org/ifcOWL/IFC2X3_TC1#relatedObjects_IfcRelDecomposes"))
							System.out.println("decompo: " + object.asResource().getURI());
						char last = object.asResource().getURI()
								.charAt(object.asResource().getURI().length() - 1);
						if (object.asResource().getURI().contains("_") && Character.isDigit(last)) {
							or = entity_model.createResource();
						} else
							or = entity_model.createResource(object.asResource().getURI());
						resources_map.put(object.asResource().getURI(), or);
					}

					String og = uri2guid.get(or.getURI());
					if (og != null) {
						String on = or.getURI().substring(0, (or.getURI().lastIndexOf("/") + 1)) + og;
						or = entity_model.createResource(on);
					}
					entity_model.add(entity_model.createStatement(subject, property, or));
				} else {
					Literal hp_literal = entity_model.createLiteral(object.toString());
					entity_model.add(entity_model.createStatement(subject, property, hp_literal));
				}

			}
			createMerkleNode(g.getGuid(), entity_model, guid_subject);

		}
	}
	
	private boolean directory_random_created = false;


	private void createMerkleNode(String guid, Model model, Resource guid_subject) {
		try {
			RDFC14Ner r1=new RDFC14Ner(model);

			String cleaned=canonized_pattern.clean(r1.getCanonicalString());

			
			NamedStreamable.ByteArrayWrapper file = new NamedStreamable.ByteArrayWrapper(guid,
					cleaned.getBytes());
			List<MerkleNode> node = ipfs.add(file);
			if(node.size()==0)
				return;
			if (guid_subject != null) {
				Resource guid_resource = jena_guid_directory_model.createResource(baseURI + URLEncoder.encode(guid));
				Literal hash_literal = jena_guid_directory_model.createLiteral(node.get(0).hash.toBase58());
				jena_guid_directory_model.add(jena_guid_directory_model.createStatement(guid_resource, this.jena_property_merkle_node, hash_literal));

				Property hp_type = model.getProperty("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
				RDFNode guid_class = null;
				
				for (Statement st : guid_subject.listProperties(hp_type).toList())
					guid_class = st.getObject();
				Resource apache_guid_resource = jena_guid_directory_model.createResource(guid_resource.getURI());
				if(guid_class==null)
				{
					System.err.println("No GUID type.");
					return;
				}

				if(!guid_class.isResource())
					return;
				jena_guid_directory_model.add(jena_guid_directory_model.createStatement(apache_guid_resource, RDF.type, guid_class));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private MerkleNode publishDirectoryNode2IPFS(String project_name, Model model) {
		List<MerkleNode> node = null;

		try {
			RDFC14Ner r1=new RDFC14Ner(model);
			String cleaned=canonized_pattern.clean(r1.getCanonicalString());

			NamedStreamable.ByteArrayWrapper file = new NamedStreamable.ByteArrayWrapper(project_name,
					cleaned.getBytes());
			node = ipfs.add(file);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if(node==null || node.size()==0)
			return null;
		return node.get(0);
	}
	

	public static String publish(String topic, String content) {
		String urlToRead = "http://127.0.0.1:5001/api/v0/pubsub/pub?arg=" + URLEncoder.encode(topic) + "&arg="
				+ URLEncoder.encode(content);
		StringBuilder result = new StringBuilder();
		URL url;
		try {
			url = new URL(urlToRead);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			rd.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	private static void testAllFiles(File curDir) {
		Scanner scanner = new Scanner(System.in);
		File[] filesList = curDir.listFiles();
		for (File f : filesList) {
			if (f.isFile()) {
				try {
					new IfcIPFS(f.getAbsolutePath());
				} catch (InterruptedException | IOException e) {
					e.printStackTrace();
				}
				System.out.println(IfcIPFS.current_process.toString());
			}
		}

	}
	
	
	public static void main(String[] args) {
		File testset = new File("c:\\ifc_models1\\");
	    testAllFiles(testset);
		
	    
		/*
		Collections.sort(statistics);
		for (Statistics s : statistics)
			System.out.println(s);*/
	}

}
